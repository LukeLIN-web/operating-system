# OS Lab5

> 郭子扬

## 实验步骤

### 环境搭建

组织文件结构

<img src="/Users/guoziyang/Library/Application Support/typora-user-images/image-20201221173549098.png" alt="image-20201221173549098" style="zoom:60%;" />

修改Makefile

arch/riscv/kernel

```makefile
.PHONY : all
all : head.o entry.o strap.o sched.o vm.o

head.o : head.S 
	$(GCC) $(CFLAG) head.S

entry.o : entry.S
	$(GCC) $(CFLAG) entry.S

strap.o : strap.c ../include/put.h ../include/syscall.h
	$(GCC) $(CFLAG) strap.c

sched.o : sched.c ../include/sched.h ../include/rand.h
	$(GCC) $(CFLAG) sched.c

vm.o : vm.c ../include/vm.h ../include/put.h
	$(GCC) $(CFLAG) vm.c

```

Makefile

```makefile
export
CROSS_= riscv64-unknown-elf-
AR=${CROSS_}ar
GCC=${CROSS_}gcc
LD=${CROSS_}ld
OBJCOPY=${CROSS_}objcopy

ISA ?= rv64imafd
ABI ?= lp64

INCLUDE = -I ../include
CF = -g -O3 -march=$(ISA) -mabi=$(ABI) -mcmodel=medany -ffunction-sections \
		-fdata-sections -nostartfiles -nostdlib -nostdinc -static -lgcc -Wl,--nmagic -Wl,--gc-sections
CFLAG = ${CF} ${INCLUDE} -c -DPRIORITY

RISCV = arch/riscv/
INIT = init/
KERNEL = arch/riscv/kernel/
LIB = lib/

.PHONY : all ${LIB} ${INIT} ${KERNEL} ${RISCV} 
all : ${LIB} ${INIT} ${KERNEL} ${RISCV}

${LIB} : 
	make -C ${LIB}
${INIT} :
	make -C ${INIT}
${KERNEL} :
	make -C ${KERNEL}
${RISCV} :
	make -C ${RISCV}

run : 
	qemu-system-riscv64 -nographic -machine virt -kernel vmlinux

debug : 
	qemu-system-riscv64 -nographic -machine virt -kernel vmlinux -S -s

run-hello:
	qemu-system-riscv64 -nographic -machine virt -kernel vmlinux -initrd hello.bin

debug-hello:
	qemu-system-riscv64 -nographic -machine virt -kernel vmlinux -initrd hello.bin -S -s 

.PHONY : clean
clean :
	rm vmlinux init/main.o init/test.o arch/riscv/kernel/head.o arch/riscv/boot/Image lib/put.o lib/rand.o arch/riscv/kernel/entry.o arch/riscv/kernel/strap.o System.map arch/riscv/kernel/sched.o arch/riscv/kernel/vm.o 
```

### 添加系统调用处理函数

handler_s

```c
#include "put.h"
#include "sched.h"
#include "syscall.h"
int cntTimeI;
int cntPut;

void handler_s(size_t scause, size_t sepc, uintptr_t *regs) {
    if (scause == 12 || scause == 13 || scause == 15) {
        puts("page fault\n");
        while(1) ;
    } else if (scause == (((unsigned long)1 << 63) | 5)){
        do_timer();
    } else if (scause == ((unsigned long)8)) {
        __asm__ __volatile__("csrr t0, sepc\n\taddi t0, t0, 4\n\tcsrrw x0, sepc, t0\n\t");
        unsigned long a7 = regs[16];
        if (a7 == 64) {
            unsigned long a0 = sys_write(regs[9], regs[10], regs[11]);
            regs[9] = a0;
        } else if (a7 == 172) {
            unsigned long a0 = sys_getpid();
            regs[9] = a0;
        }
    }
}
```

syscall.h

```c
#include "sched.h"
#include "put.h"


unsigned long sys_write(unsigned int fd, const char* buf, size_t count) {
    if (fd == 1) {
        puts(buf);
        return count;
    }
}

unsigned long sys_getpid() {
    return current->pid;
}
```

### 修改进程初始化以及进程调度相关逻辑

#### task struct的修改

```c
#define size_t unsigned long long

struct mm_struct {
    unsigned long *pgtbl; // 页表顶级项地址
    unsigned long text_start; // 代码其起始地址
    unsigned long text_end;
    unsigned long stack_top; // 栈顶
};

/* 进程状态段数据结构 */
struct thread_struct {
    size_t ra;
    size_t sp;
    size_t s0;
    size_t s1;
    size_t s2;
    size_t s3;
    size_t s4;
    size_t s5;
    size_t s6;
    size_t s7;
    size_t s8;
    size_t s9;
    size_t s10;
    size_t s11;
    size_t sepc;
    size_t sscratch;
    struct mm_struct *mm;
};
```

#### 内存空间分配

调用creat_mapping函数来建立虚地址映射。

```c
struct kernel_mem_struct {
    unsigned long text_start, rodata_start, data_start;
    unsigned long virtual_offset;
};

void initial_pgtbl(unsigned long pgtbl) {
    unsigned long text_start = kmem_struct.text_start, rodata_start = 
    		kmem_struct.rodata_start, data_start = kmem_struct.data_start;
    unsigned long virtual_offset = kmem_struct.virtual_offset;
    create_mapping(pgtbl, virtual_offset + text_start, text_start, 
    		rodata_start - text_start, 5);
    create_mapping(pgtbl, virtual_offset + rodata_start, rodata_start, 
    		data_start - rodata_start, 1);
    create_mapping(pgtbl, virtual_offset + data_start, data_start, 
    		0x1000000 - (data_start - text_start), 3);

    create_mapping(pgtbl, 0xffffffdf90000000, 0x10000000, 0x1000, 3);

    static unsigned long stack_page_top = 0x84001000;
    create_mapping(pgtbl, 0xffffffdf80000000 - 0x1000, stack_page_top, 0x1000, 11);
    stack_page_top += 0x1000;
    create_mapping(pgtbl, 0x0, 0x84000000ul, 0x1000, 15);
}
```

####  用户栈与内核栈

使用`sscratch`保存内核栈顶，在进入trap_s后与`sp`交换。之后使用内核栈。

```assembly
trap_s:
    csrrw sp, sscratch, sp

    addi sp, sp, -280

    sd x1, 0(sp)
    sd x2, 8(sp)
    sd x3, 16(sp)
    sd x4, 24(sp)
   	
   	...
   	
   	# handler_s
   	
   	...
   
   
    ld x3, 16(sp)
    ld x2, 8(sp)
    ld x1, 0(sp)
    addi sp, sp, 280
    csrrw sp, sscratch, sp
    sret
```

sched.c

```c
__asm__ __volatile__("csrr t0, sepc\n\tadd %0, t0, x0\n\t"
    :"=r"(current->thread.sepc)
    );
__asm__ __volatile__("csrr t0, sscratch\n\tadd %0, t0, x0\n\t"
    :"=r"(current->thread.sscratch)
    );

__asm__ __volatile__("add t0, %0, x0\n\tcsrrw x0, sepc, t0\n\t"
    : :"r"(next->thread.sepc)
    );
__asm__ __volatile__("add t0, %0, x0\n\tcsrrw x0, sscratch, t0\n\t"
    : :"r"(next->thread.sscratch)
    );
__asm__ __volatile__("addi t0, t0, 1\n\tslli t0, t0, 63\n\tsrl t1, %0, 12\n\tor t0, t0, t1\n\tcsrrw x0, satp, t0\n\t"
    : :"r"(next->thread.mm->pgtbl)
    );
```

在进程迁移的时候对`sscratch`、`sepc`和`satp`进行设置。

### 用户态测试程序

在Makefile中增加命令

```makefile
run-hello:
	qemu-system-riscv64 -nographic -machine virt -kernel vmlinux -initrd hello.bin

debug-hello:
	qemu-system-riscv64 -nographic -machine virt -kernel vmlinux -initrd hello.bin -S -s 
```

### 编译及测试

<img src="/Users/guoziyang/Library/Application Support/typora-user-images/image-20201221182806254.png" alt="image-20201221182806254" style="zoom:50%;" />

## 心得体会

 本次实验在之前线程调度的基础上增加了虚拟地址，使得之前实验的很多疑问都得到了解决。比如在task_struct中增加几位数据可以解决许多之前实验只能放在栈中保存的数据。

卡住时间比较久的bug：在创建页表时直接使用了字面量`0x84000000`传入`create_mapping`函数，改值先被解析为int类型，后传入参数里的`unsigned long`类型，导致错误。经验总结：数字字面量的时候要使用类型对应的后缀（比如unsigned int为\*u，unsigned long为\*ul）

## 对实验指导的建议

1. 页表项中需要对U位置1，在本次实验手册中没有给出说明。

2. 若在S-mode下需要访问页表项U位置1的的页表，需要将mstatus中的SUM位置1，这点同样的在手册中未给出说明。

   